from ..cmd import APPSCommand
from ..defines import *
from pprint import pformat
import logging
import sys


def get_parser():
    return APPSApprove().parser


class APPSApprove(APPSCommand):
    DESCRIPTION = 'Approve the specified data for processing by the GDGPS Automatic Precise Point Positioning' \
                  ' Service.'

    logger = logging.getLogger(__name__ + '.APPSApprove')

    VALID_STATES = [Data.VERIFIED]

    def __init__(self):

        super(APPSApprove, self).__init__()

        self.parser.add_argument(
            'selectors',
            metavar='D',
            nargs='*',
            help='The selector specifying the data(s) to approve for processing. If no identifiers are given all '
                 'verified data is approved. ' + self.DATA_SELECTOR_HELP % (
                [Data.get_verbose_state(state) for state in self.VALID_STATES],
            )
        )

        self.parser.add_argument(
            '--no-progress',
            action='store_true',
            dest='no_progress',
            help='Turn off authorization progress updates.',
            default=False
        )

    def _main(self):

        self.apps.list_data()

        selectors = self.args.selectors if len(self.args.selectors) > 0 else [Data.VERIFIED]

        ids = self.resolve_selectors(
            selectors,
            valid_states=self.VALID_STATES
        )

        if len(ids) == 0:
            return 'No data matched selection for approval.'

        if self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug('Approve data set: %s', pformat(ids))

        for uuid in ids:
            self.logger.debug('Authorizing %s...', uuid)

            if self.apps.approve(uuid):
                if not self.args.no_progress:
                    print('Approved %s for processing.' % uuid)
            else:
                return 'Error approving %s.' % uuid


def main():
    cmd = APPSApprove()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
