from ..cmd import APPSCommand
from ..interactive import APPSCmdLine
import os
import sys


def get_parser():
    return APPSInteractive().parser


class APPSInteractive(APPSCommand):
    DESCRIPTION = 'Launch the APPS interactive shell.'

    def __init__(self):
        super(APPSInteractive, self).__init__()

        self.parser.add_argument(
            '-d',
            '--download-dir',
            type=str,
            dest='download_dir',
            default=os.getcwd(),
            help='The destination directory for downloaded files.',
            required=False
        )

    def _main(self):
        APPSCmdLine(
            settings_file=self.args.settings,
            download_directory=self.args.download_dir,
            trust_env=self.args.trust_env
        ).cmdloop()


def main():
    cmd = APPSInteractive()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
