from ..cmd import APPSCommand
from pprint import pformat
from gdgps_apps.defines import GIPSYData
import glob
import logging
import os
import sys


def get_parser():
    return APPSUpload().parser


class APPSUpload(APPSCommand):
    DESCRIPTION = 'Submit data to the GDGPS Automatic Precise Point Positioning Service for processing.'
    OPTIONS = 'gipsyxdata'

    logger = logging.getLogger(__name__ + '.APPSUpload')

    def __init__(self):

        super(APPSUpload, self).__init__()

        self.parser.add_argument(
            'files',
            metavar='F',
            nargs='+',
            help='The list of files to upload.',
        )

        self.parser.add_argument(
            '--antenna-calibration-file',
            type=str,
            dest='antCal',
            help='A file containing antenna calibration.',
            default=None
        )

        self.parser.add_argument(
            '--pressure-file',
            type=str,
            dest='pressure',
            help='A file containing atmospheric pressure measurements to use. Will force troposphere model to'
                 '`Provided`.',
            default=None
        )

        self.parser.add_argument(
            '--attitude-file',
            type=str,
            dest='attitude',
            help='A file containing the attitude quaternions (%s mode only).' %
                 GIPSYData.get_verbose_processing_mode(GIPSYData.KINEMATIC),
            default=None
        )

        self.parser.add_argument(
            '--no-progress',
            action='store_true',
            dest='no_progress',
            help='Turn off the upload progress indicator.',
            default=False
        )

        self.parser.add_argument(
            '--processor',
            type=str,
            dest='processor',
            help='Force upload to a given processor, identified by label.',
            default=None
        )

    def _main(self):

        files = []
        for file in self.args.files:
            files.extend([os.path.normpath(path) for path in glob.glob(file)])

        if self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug('Upload file set: %s', pformat(files))

        if len(files) == 0:
            return 'No files match %s' % (self.args.files,)

        antCal = None
        if self.args.antCal:
            antCal = os.path.normpath(self.args.antCal)
            if not os.path.isfile(antCal):
                return '%s is not a file.' % (antCal,)

        pressure = None
        if self.args.pressure:
            pressure = os.path.normpath(self.args.pressure)
            if not os.path.isfile(pressure):
                return '%s is not a file.' % (pressure,)
            self.args.troposphere_model = GIPSYData.TROP_PROVIDED

        attitude = None
        if self.args.attitude:
            attitude = os.path.normpath(self.args.attitude)
            if not os.path.isfile(attitude):
                return '%s is not a file.' % (attitude,)

            if getattr(self.args, 'generate_quaternions', None):
                return 'Must specify either --generate-quaternions OR give an attitude file.'

        processor = None
        if hasattr(self.args, 'processor') and self.args.processor:
            processor = self.args.processor

        all_ret = []
        for file in files:

            file = os.path.normpath(file)
            if os.path.isfile(file):
                self.logger.debug('Uploading %s...' % (file,))
                if self.args.no_progress or self.args.json:
                    ret = self.apps.upload_gipsyx(
                        file,
                        antCal=antCal,
                        pressure=pressure,
                        attitude=attitude,
                        stream=True,
                        processor=processor,
                        **self.build_option_dict(self.OPTIONS, self.args)
                    ).json()
                    if not self.args.json:
                        print(
                            'Uploaded: %s, size=%s, id=%s' % (
                                file,
                                self.format_size(ret['data_size_uploaded']),
                                ret['id']
                            )
                        )
                else:
                    from tqdm import tqdm
                    postfix = {'file': os.path.basename(file)}
                    if antCal:
                        postfix['antCal'] = os.path.basename(antCal)
                    if pressure:
                        postfix['pressure'] = os.path.basename(pressure)
                    if attitude:
                        postfix['attitude'] = os.path.basename(attitude)
                    with tqdm(
                            total=os.path.getsize(file),
                            unit='B',
                            unit_scale=True,
                            unit_divisor=1024,
                            postfix=postfix
                    ) as progress_bar:
                        ret = self.apps.upload_gipsyx(
                            file,
                            antCal=antCal,
                            pressure=pressure,
                            attitude=attitude,
                            stream=True,
                            processor=processor,
                            progress_hook=lambda bytes_read: progress_bar.update(bytes_read),
                            **self.build_option_dict(self.OPTIONS, self.args)
                        ).json()
                        postfix['id'] = ret['id']
                        progress_bar.set_postfix(postfix)
                all_ret.append(ret)
            else:
                return '%s is not a file.' % (file,)

        if self.args.json:
            self.pretty_print_json(all_ret)


def main():
    cmd = APPSUpload()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
