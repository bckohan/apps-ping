from ..cmd import APPSCommand
from ..defines import *
import logging
import sys


def get_parser():
    return APPSDelete().parser


class APPSDelete(APPSCommand):
    DESCRIPTION = 'Delete data, flags, or alerts matching the given selectors.'

    logger = logging.getLogger(__name__ + '.APPSDelete')

    VALID_STATES = [ s[0] for s in Data.STATES ]

    def __init__(self):

        super(APPSDelete, self).__init__()

        self.parser.add_argument(
            'selectors',
            metavar='D',
            nargs='+',
            help='The selector specifying the data(s), flag(s) or alert(s) to delete. Selectors for flags or alerts are'
                 ' the object\'s UUIDs. ' + self.DATA_SELECTOR_HELP % (
                [Data.get_verbose_state(state) for state in self.VALID_STATES],
            )
        )

        self.parser.add_argument(
            '-a',
            '--alert',
            action='store_true',
            dest='alert',
            help='Delete selected alerts. Alerts can be selected by ID, level or header string.',
            default=False
        )

        self.parser.add_argument(
            '--flag',
            action='store_true',
            dest='flag',
            help='Delete selected data flags. If more than one selector is given, the first will be assumed to be a '
                 'data selector. Flags can be selected by ID, level or header string.',
            default=False
        )

        self.parser.add_argument(
            '-f',
            '--force',
            action='store_true',
            dest='force',
            help='Never prompt for deletion confirmation.',
            default=False
        )

        self.parser.add_argument(
            '--no-progress',
            action='store_true',
            dest='no_progress',
            help='Turn off the delete progress indicator.',
            default=False
        )

        self.parser.add_argument(
            '--strict',
            action='store_true',
            dest='strict',
            help='Abort if any data selectors do not match data.',
            default=False
        )

    def _main(self):

        self.apps.list_data()

        if self.args.alert:
            alerts_to_delete = [alert for alert in self.resolve_alert_selectors(self.args.selectors) if
                                not alert['sticky']]
            if len(alerts_to_delete) == 0 and not self.args.no_progress:
                print('No non-sticky alerts matched the selection criteria for deletion.')
            for alert in alerts_to_delete:
                if self.apps.delete_alert(alert['id']) and not self.args.no_progress:
                    print('Alert %s deleted.' % (alert['id'],))

        elif self.args.flag:

            dataids = [None]
            selectors = self.args.selectors
            if len(self.args.selectors) > 1:
                dataids = self.resolve_selectors([self.args.selectors[0]])
                selectors = self.args.selectors[1:]

            for dataid in dataids:
                flags_to_delete = [flag for flag in self.resolve_flag_selectors(selectors, dataid=dataid) if
                                   not flag['sticky']]
                if len(flags_to_delete) == 0 and not self.args.no_progress:
                    print('No non-sticky data flags matched the selection criteria for deletion.')
                for flag in flags_to_delete:
                    if self.apps.delete_flag(flag['id']) and not self.args.no_progress:
                        print('Flag %s deleted.' % (flag['id'],))

        else:

            ids = self.resolve_selectors(self.args.selectors, raise_for_not_found=(self.args.strict==False))

            if len(ids) == 0:
                return 'No data matched selection for deletion.'

            for uuid in ids:
                info = self.apps.cached_data()[uuid]
                if not self.args.force:
                    warn_str = ''
                    if info['state'] == Data.AVAILABLE:
                        warn_str = ' The results are available but they have not been downloaded!'
                    resp = input('Are you sure you want to delete %s, in state %s.%s (y/n) [n]? ' % (
                        info['name'],
                        Data.get_verbose_state(info['state']),
                        warn_str
                    ))
                    if resp.lower() not in ['y', 'yes']:
                        continue

                self.apps.delete_data(uuid)
                print('Deleted data [ %s | %s ]' % (info['name'], uuid))


def main():
    cmd = APPSDelete()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
