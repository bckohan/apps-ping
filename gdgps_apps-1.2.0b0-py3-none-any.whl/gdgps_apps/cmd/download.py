from ..cmd import APPSCommand
from ..defines import *
from pprint import pformat
import re
import logging
import os
import sys


def get_parser():
    # there is a bug somewhere in sphinx argparse that pulls out sys.argv[1] as the subcommand, this errors out
    # when generating the docs because its unrecognized by the parse - this works around the problem without any
    # side effects
    sys.argv[1] = 'results'
    return APPSDownload().parser


class APPSDownload(APPSCommand):
    DESCRIPTION = 'Download the specified data from the GDGPS Automatic Precise Point Positioning Service.'

    logger = logging.getLogger(__name__ + '.APPSDownload')

    chunk_size = 32 * 1024

    VALID_STATES = [s[0] for s in Data.STATES]

    def __init__(self):

        super(APPSDownload, self).__init__()

        self.parser.add_argument(
            'selectors',
            metavar='D',
            nargs='*',
            help='The selector specifying the data(s) to download. If no identifiers are given download all ' \
                 'unretrieved available results. ' + self.DATA_SELECTOR_HELP % (
                     [Data.get_verbose_state(state) for state in self.VALID_STATES],
                 )
        )

        self.parser.add_argument(
            '-d',
            '--download-dir',
            type=str,
            dest='download_dir',
            help='The directory to save downloaded files to. Defaults to the current working directory.',
            default=None
        )

        self.parser.add_argument(
            '--no-progress',
            action='store_true',
            dest='no_progress',
            help='Turn off the upload progress indicator.',
            default=False
        )

        download_parsers = self.parser.add_subparsers(help='Select sources or results to download.')

        sources_parser = download_parsers.add_parser(
            'sources',
            help='Download sources.'
        )
        source_types = []
        for rt in GIPSYXData.SOURCE_TYPES:
            source_types.append(rt[0])
            source_types.append(rt[1])
        sources_parser.add_argument(
            '-t',
            '--type',
            dest='stypes',
            action='append',
            choices=source_types,
            help=f'The type of the sources to download. Default: '
                 f'{GIPSYXData.get_verbose_source_type(GIPSYXData.RINEX_FILE)}',
            default=[]
        )
        sources_parser.set_defaults(subcmd='sources')

        results_parser = download_parsers.add_parser(
            'results',
            help='Download results.'
        )
        result_types = []
        for rt in GIPSYXData.RESULT_TYPES:
            result_types.append(rt[0])
            result_types.append(rt[1])
        results_parser.add_argument(
            '-t',
            '--type',
            dest='rtypes',
            action='append',
            choices=result_types,
            help=f'The type of the files to download.  Default: '
                 f'{GIPSYXData.get_verbose_result_type(GIPSYXData.ARCHIVE_FILE)}',
            default=[]
        )
        results_parser.set_defaults(subcmd='results')

        run_parser = download_parsers.add_parser(
            'run',
            help='Download the run directory archive.'
        )
        run_parser.set_defaults(subcmd='run')

    def _main(self):

        self.apps.download_directory = self.args.download_dir

        if self.args.subcmd == 'run' and not (self.apps.is_staff or self.apps.is_superuser):
            return 'run data is not available at your user level.'

        self.apps.list_data()

        selectors = self.args.selectors if len(self.args.selectors) > 0 else [Data.AVAILABLE]
        ids = self.resolve_selectors(
            selectors,
            valid_states=[Data.AVAILABLE, Data.RETRIEVED]
        )

        if len(ids) == 0:
            return 'No data matched selection for download.'

        if self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug('Download data set: %s', pformat(ids))

        types = [
            *[GIPSYXData.normalize_source_type(t) for t in getattr(self.args, 'stypes', [])],
            *[GIPSYXData.normalize_result_type(t) for t in getattr(self.args, 'rtypes', [])],
        ]
        if not types:
            if self.args.subcmd == 'results':
                types.append(GIPSYXData.ARCHIVE_FILE)
            elif self.args.subcmd == 'sources':
                types.append(GIPSYXData.RINEX_FILE)

        def write_to_disk(resp):
            if resp and resp.ok:

                dr = self.apps.download_directory
                if not (os.path.exists(dr) and os.path.isdir(dr)):
                    raise ValueError('%s is not a valid download directory.' % dr)

                size = None
                if 'content-length' in resp.headers:
                    size = int(resp.headers['content-length'])

                filename = re.findall('filename=(.+)', resp.headers['content-disposition'])
                dl_path = os.path.normpath(dr + '/' + filename[0].replace('"', ''))

                with tqdm(
                        total=size,
                        unit='B',
                        unit_scale=True,
                        unit_divisor=1024,
                        postfix={'file': dl_path}
                ) as progress_bar:
                    with open(dl_path, 'wb') as dout:
                        while True:
                            chunk = resp.raw.read(self.chunk_size)
                            if not chunk:
                                break
                            progress_bar.update(dout.write(chunk))

            elif not resp:
                return '%s is unavailable for download!' % uuid
            else:
                return 'Error downloading %s: %s, %s' % (uuid, resp.status_code, resp.content)

        for uuid in ids:
            self.logger.debug('Downloading %s...', uuid)
            if self.args.no_progress:
                if self.args.subcmd == 'run':
                    self.apps.download_run(uuid)
                else:
                    for subtype in types:
                        if self.args.subcmd == 'sources':
                            self.apps.download_source(uuid, source_type=subtype)
                        elif self.args.subcmd == 'results':
                            self.apps.download_result(uuid, result_type=subtype)
            else:
                from tqdm import tqdm
                if self.args.subcmd == 'run':
                    write_to_disk(
                        self.apps.download_run(
                            uuid,
                            stream=True,
                            write_to_disk=False
                        )
                    )
                else:
                    for subtype in types:
                        if self.args.subcmd == 'sources':
                            write_to_disk(
                                self.apps.download_source(
                                    uuid,
                                    source_type=subtype,
                                    stream=True,
                                    write_to_disk=False
                                )
                            )
                        elif self.args.subcmd == 'results':
                            write_to_disk(
                                self.apps.download_result(
                                    uuid,
                                    result_type=subtype,
                                    stream=True,
                                    write_to_disk=False
                                )
                            )


def main():
    cmd = APPSDownload()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
