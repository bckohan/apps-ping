from ..cmd import APPSCommand
from ..defines import Data
from pprint import pformat
import logging
import sys


def get_parser():
    return APPSDetail().parser


class APPSDetail(APPSCommand):
    DESCRIPTION = 'List all details for a given data item.'

    logger = logging.getLogger(__name__ + '.APPSDetail')

    VALID_STATES = []

    def __init__(self):

        super(APPSDetail, self).__init__()

        self.parser.add_argument(
            'selector',
            metavar='D',
            nargs=1,
            help='The data to list the details of. ' + self.DATA_SELECTOR_HELP_SINGULAR
        )

    def _main(self):

        self.apps.list_data()

        ids = self.resolve_selectors(
            self.args.selector,
            valid_states=self.VALID_STATES
        )

        if len(ids) == 0:
            return 'No data matched selection for retrieval.'

        elif len(ids) > 1:
            return 'May only detail one data at a time but selector matched more than on data item: %s' % pformat(ids)

        uuid = ids[0]

        if self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug('Fetching details for data: %s', uuid)

        self.pretty_print_json(self.apps.detail(uuid))


def main():
    cmd = APPSDetail()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
