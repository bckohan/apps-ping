from ..cmd import APPSCommand
from ..defines import Data
from gdgps_apps import defines
import logging
import sys



def get_parser():
    return APPSList().parser

class APPSList(APPSCommand):
    DESCRIPTION = 'List the basic information for the specified data item(s) stored on the GDGPS Automatic Precise ' \
                  'Point Positioning Service.'

    logger = logging.getLogger(__name__ + '.APPSList')

    # todo automagically grab these from the api view?
    valid_filter_fields = ('name', 'state', 'error_state', 'processor__label', 'src_available')

    VALID_STATES = [s[0] for s in Data.STATES]

    def __init__(self):

        super(APPSList, self).__init__()

        self.parser.add_argument(
            'selectors',
            metavar='D',
            nargs='*',
            help='The selectors matching data items to list. If no selectors are given list all data.' \
                 + self.DATA_SELECTOR_HELP % ([Data.get_verbose_state(state) for state in self.VALID_STATES],),
        )

        self.parser.add_argument(
            '-c',
            '--count',
            action='store_true',
            dest='count',
            default=False,
            help='Only print the number of data items in the list. Default: False'
        )

        '''
        self.parser.add_argument(
            '-i',
            '--includes',
            nargs='*',
            dest='includes',
            help='The list of fields to include in the list. Default: All fields'
        )

        self.parser.add_argument(
            '-e',
            '--excludes',
            nargs='*',
            dest='excludes',
            help='The list of fields to exclude from the list. Default: No fields'
        )
        '''

        self.parser.add_argument(
            '--search',
            dest='search',
            required=False,
            help='Search the data item name fields for the given string.'
        )

        self.parser.add_argument(
            '-f',
            '--filter',
            nargs='*',
            dest='filters',
            help='A list of field filters to apply. Filters should be <fieldname>=<value> and valid filter fields '
                 'include: %s' % (self.valid_filter_fields,)
        )

        self.parser.add_argument(
            '-o',
            '--order',
            nargs='*',
            dest='ordering',
            help='Order the response by the values of the given fields. For reverse order, prepend a "-": -o "-time"'
        )


    def _main(self):

        query = {}

        '''
        if self.args.includes is not None and len( self.args.includes ) > 0:
            query['include[]'] = self.args.includes

        if self.args.excludes is not None and len( self.args.excludes ) > 0:
            query['exclude[]'] = self.args.excludes
        '''

        if self.args.ordering is not None and len(self.args.ordering) > 0:
            query['ordering'] = self.args.ordering

        if self.args.search is not None and len(self.args.search) > 0:
            query['search'] = self.args.search

        if self.args.filters is not None and len(self.args.filters) > 0:
            for fltr in self.args.filters:
                f = fltr.split('=')
                if len(f) != 2:
                    raise Exception(
                        'Invalid filter parameter format \'%s\' must be <fieldname>=<value> and valid fields include '
                        '%s' % (fltr, self.valid_filter_fields)
                    )
                if f[0] not in self.valid_filter_fields:
                    raise Exception(
                        'Invalid filter field \'%s\', valid fields include: %s' % (f[0], self.valid_filter_fields))
                query[f[0]] = f[1]

        lst = self.apps.list_data(query=query)
        
        ids = None
        if len(self.args.selectors) > 0:
            ids = self.resolve_selectors(self.args.selectors)

        if ids is None:
            if self.args.count:
                print(len(self.apps.cached_data()))
            else:
                if self.args.json:
                    self.pretty_print_json(lst) 
                else:
                    for entry in lst:
                        print(
                            "id: %s  name: %s  state: %s" % (
                                entry["id"],
                                entry["name"],
                                defines.Data.get_verbose_state(entry["state"])
                            )
                        )
        else:
            if self.args.count:
                print(len(ids))
            else:
                self.pretty_print_json([self.apps.cached_data()[uuid] for uuid in ids]) 


def main():
    cmd = APPSList()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
