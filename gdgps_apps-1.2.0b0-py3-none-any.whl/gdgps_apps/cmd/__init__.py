import argparse
from ..apps import APPS
from ..defines import *
from ..exceptions import *
from requests.exceptions import HTTPError
from copy import copy
import json
import logging


def get_verbose_states(states=None):
    if states is None:
        states = []
    return [state[1] for state in Data.STATES if state[0] in states]


class APPSCommand(object):
    DESCRIPTION = None
    OPTIONS = None

    parser_ = None
    apps_ = None
    args_ = None

    logger = logging.getLogger(__name__ + '.APPSCommand')

    DATA_SELECTOR_HELP_SINGULAR = 'A valid data selector is the universal data identifier in the form ' \
                                  'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX or the data\'s name string.'

    DATA_SELECTOR_HELP = 'Valid data selectors are universal data identifiers in the form ' \
                         'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX, data name strings, the shortcut \'all\' for all ' \
                         'data, or one of the following states: %s'

    def __init__(self):

        default_settings_path = '~/.apps_settings'

        self.parser.add_argument(
            '-s',
            '--settings',
            type=str,
            default=default_settings_path,
            help='APPS configuration parameters, including access credentials. See the website, to download this file. '
                 'Default: ' + default_settings_path,
            required=False
        )

        self.parser.add_argument(
            '--log-level',
            type=str.upper,
            dest='log_level',
            choices=(
                'OFF',
                'DEBUG',
                'INFO',
                'WARNING',
                'ERROR',
                'CRITICAL'
            ),
            default='OFF',
            help='Set the logging level, OFF is silent and DEBUG is the highest verbosity. Default: OFF',
        )

        self.parser.add_argument(
            '--trust-env',
            action='store_true',
            dest='trust_env',
            default=False,
            help='Trust environment settings for proxy configuration, default authentication and similar. '
                 'Default: False'
        )

        self.parser.add_argument(
            '--no-verify',
            action='store_false',
            dest='verify',
            default=True,
            help='Do not verify SSL certificates.'
        )

        self.parser.add_argument(
            '--stack-trace',
            action='store_true',
            dest='stack_trace',
            default=False,
            help='Allow exceptions to propagate out. Default: False'
        )

        self.parser.add_argument(
            '-j',
            '--json',
            action='store_true',
            dest='json',
            default=False,
            help='Print all output in json format to facilitate machine parsing of command returns. If not enabled some'
                 ' commands will attempt to print status information in a more human friendly format. Default: False'
        )

        self.add_options(self.OPTIONS, self.parser)

    @property
    def parser(self):
        if self.parser_ is None:
            self.parser_ = argparse.ArgumentParser(self.DESCRIPTION)
        return self.parser_

    @property
    def args(self):
        if self.args_ is None:
            self.args_ = self.parser.parse_args()
            APPS.set_log_level(self.args_.log_level)
        return self.args_

    @property
    def apps(self):
        if self.apps_ is None:
            self.apps_ = APPS(
                settings_file=self.args.settings,
                trust_env=self.args.trust_env,
                verify=self.args.verify,
                log_level=self.args.log_level
            )
        return self.apps_

    @staticmethod
    def add_options(cmd_type, parser, excludes=None, defaults=None):

        if excludes is None:
            excludes = []

        if defaults is None:
            defaults = {}

        if cmd_type is not None and cmd_type in APPS.OPTIONS:
            for option, params in APPS.OPTIONS[cmd_type].items():
                if option in excludes:
                    continue
                arg_long_name = '--' + option.replace('_', '-')
                arg_short_name = None if 'short' not in params else '-' + params['short']

                hlp = '' if 'help' not in params or params['help'] is None else params['help']
                default = defaults.get(option, None)
                if default is None:
                    default = params.get('default', None)
                if isinstance(default, bool):
                    default = 'on' if default else 'off'
                if default is not None:
                    hlp += f' Default: {default}'

                param_args = {
                    'dest': option,
                    'default': None,
                    'help': hlp
                }

                if params['type'] != bool:
                    param_args['type'] = params['type']
                else:
                    param_args['action'] = 'store_true'

                if 'required' in params:
                    param_args['required'] = params['required']

                if 'choices' in params:
                    param_args['choices'] = tuple([choice[0] for choice in params['choices']])

                if arg_short_name:
                    parser.add_argument(arg_long_name, arg_short_name, **param_args)
                else:
                    parser.add_argument(arg_long_name, **param_args)

                if params['type'] == bool:
                    disable_args = copy(param_args)
                    disable_args['action'] = 'store_false'
                    disable_args['help'] = None
                    parser.add_argument(arg_long_name.replace('--', '--disable-'), **disable_args)

    @staticmethod
    def build_option_dict(cmd_type, args, defaults=None):
        opt_dict = {}
        if defaults is None:
            defaults = {}
        if cmd_type is not None and cmd_type in APPS.OPTIONS:
            for option, params in APPS.OPTIONS[cmd_type].items():
                val = getattr(args, option, None)
                if val is not None:
                    opt_dict[option] = val
                elif option in defaults:
                    opt_dict[option] = defaults[option]

        return opt_dict

    def resolve_selectors(self, selectors, valid_states=None, raise_for_not_found=False):

        if selectors is None:
            return []

        if isinstance(selectors, str):
            selectors = [selectors]

        ids = []
        states = []
        for selector in selectors:
            if APPS.is_id(selector):
                selector = selector.lower()
                if not self.apps.exists(selector):
                    if raise_for_not_found:
                        raise DataNotFound(uuid=selector)
                    else:
                        self.logger.warning('Selector %s did not match any data.', selector)
                ids.append(selector)
                continue

            uuid = self.apps.id_for_name(selector)
            if uuid is not None:
                ids.append(uuid)
            elif APPS.is_state(selector):
                if valid_states is not None:
                    if Data.normalize_state(selector) not in valid_states:
                        raise InvalidSelector(
                            '%s is not a valid selector. Valid selectors are universal '
                            'data identifiers in the form XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX, data name strings, the '
                            'shortcut \'all\' for all data, or one of the following states: %s' % (
                                selector, get_verbose_states(valid_states)
                            ),
                            selector=selector
                        )
                states.append(selector)
            elif selector == 'all':
                if len(self.apps.cached_data()) == 0:
                    self.apps.list_data()
                if valid_states:
                    ids.extend(self.apps.data_in_states(valid_states))
                else:
                    ids.extend(self.apps.cached_data().keys())
            else:
                if raise_for_not_found:
                    raise DataNotFound('Selector %s did not match any data!' % (selector,), uuid=selector)
                else:
                    self.logger.warning('Selector %s did not match any data.', selector)

        if len(states) > 0:
            ids.extend(self.apps.data_in_states(states))

        return ids

    def resolve_alert_selectors(self, selectors):

        if selectors is None:
            return []

        alerts = self.apps.alerts()

        selected = []
        for selector in selectors:
            selector = selector.lower()
            lvl = APPS.is_alert_level(selector)
            if selector == 'all':
                selected.extend(alerts)
            elif APPS.is_id(selector):
                found = False
                for alrt in alerts:
                    if selector == alrt['id'].lower():
                        selected.append(alrt)
                        found = True
                        break
                if not found:
                    raise AlertNotFound('Alert %s does not exist.' % (selector,), uuid=selector)

            elif lvl:
                for alrt in alerts:
                    if alrt['level'] == lvl:
                        selected.append(alrt)
            else:
                for alrt in alerts:
                    if selector == alrt['header'].lower():
                        selected.append(alrt)

        return selected

    def resolve_flag_selectors(self, selectors, dataid=None):

        if selectors is None:
            return []

        flags = self.apps.flags(dataid=dataid)

        selected = []
        for selector in selectors:
            selector = selector.lower()
            lvl = APPS.is_flag_level(selector)
            if selector == 'all':
                selected.extend(flags)
            elif APPS.is_id(selector):
                found = False
                for flag in flags:
                    if selector == flag['id'].lower():
                        selected.append(flag)
                        found = True
                        break
                if not found:
                    raise FlagNotFound('Flag %s does not exist.' % (selector,), uuid=selector)

            elif lvl:
                for flag in flags:
                    if flag['level'] == lvl:
                        selected.append(flag)
            else:
                for flag in flags:
                    if selector == flag['header'].lower():
                        selected.append(flag)

        return selected

    @staticmethod
    def pretty_print_json(content):
        print(json.dumps(content, indent=4))

    @staticmethod
    def format_size(byts):
        for unit in ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB']:
            if abs(byts) < 1024.0:
                return "%3.3f%s" % (byts, unit)
            byts /= 1024.0
        return "%.3f%s" % (byts, 'YB')

    def main(self):
        if self.args.stack_trace:
            return self._main()
        try:
            self._main()
        except HTTPError as e:
            try:
                reason = json.dumps(e.response.content, indent=4)
            except TypeError:
                reason = e.response.text
            return str(e) + '\n' + reason
        except Exception as e:
            return str(e)

    def _main(self):
        raise NotImplementedError('%s must implement main( )!' % (type(self)))
