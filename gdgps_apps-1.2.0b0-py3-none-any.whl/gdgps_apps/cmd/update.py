from ..cmd import APPSCommand
from pprint import pformat
from ..defines import GIPSYXData
import logging
import sys
import os


def get_parser():
    return APPSUpdate().parser


class APPSUpdate(APPSCommand):
    DESCRIPTION = 'Update parameters for a given GIPSYX data upload.'
    OPTIONS = 'gipsyxdata'

    logger = logging.getLogger(__name__ + '.APPSUpdate')

    VALID_STATES = [
        state for state, parms in GIPSYXData.OWNER_UPDATE_TABLE.items() if len(parms.get('fields', [])) > 0
    ]

    def __init__(self):

        super(APPSUpdate, self).__init__()

        self.parser.add_argument(
            'selectors',
            metavar='D',
            nargs='+',
            help='The selectors identifying the data to update the parameters of. ' + self.DATA_SELECTOR_HELP % (
                [GIPSYXData.get_verbose_state(state) for state in self.VALID_STATES],
            )
        )

        self.parser.add_argument(
            '--pressure-file',
            type=str,
            dest='pressure',
            help='A file containing atmospheric pressure measurements to use. If a pressure file currently exists this '
                 'file will replace it.',
            default=None
        )

        self.parser.add_argument(
            '--attitude-file',
            type=str,
            dest='attitude',
            help='A file containing the attitude quaternions (%s mode only). If an attitude quaternion source currently'
                 'exists, this file will replace it.' %
                 GIPSYXData.get_verbose_processing_mode(GIPSYXData.KINEMATIC),
            default=None
        )

        self.parser.add_argument(
            '--antenna-calibration-file',
            type=str,
            dest='antCal',
            help='A file containing antenna calibration.',
            default=None
        )

        self.parser.add_argument(
            '--rinex-file',
            type=str,
            dest='rinex',
            help='A file containing the observable data in RINEX format.',
            default=None
        )

        self.parser.add_argument(
            '--source',
            action='append',
            nargs='*',
            dest='source',
            help='Source files to add to this data submission.',
            default=None
        )

        self.parser.add_argument(
            '-d',
            '--delete-source',
            action='append',
            nargs='*',
            dest='todelete',
            help='The type of the source file(s) to delete. Must be one of: ' + ','.join(
                ['%s: %s' % (s, l) for s, l in GIPSYXData.SOURCE_TYPES]
            ),
            default=None
        )

        self.parser.add_argument(
            '--no-progress',
            action='store_true',
            dest='no_progress',
            help='Turn off the upload progress indicator. Only applies if source files are specified for upload.',
            default=False
        )

    def _main(self):

        ids = self.resolve_selectors(
            self.args.selectors,
            valid_states=self.VALID_STATES,
            raise_for_not_found=True
        )

        if len(ids) == 0:
            return 'No data items matched selection for update.'

        sources = []

        antCal = getattr(self.args, 'antCal', None)
        if antCal:
            if os.path.isfile(antCal):
                sources.append({
                    'source_type': GIPSYXData.ANTENNA_CALIBRATION_FILE,
                    'file': antCal
                })
            else:
                return 'Antenna calibration file %s does not exist.' % antCal

        attitude = getattr(self.args, 'attitude', None)
        if attitude:
            if os.path.isfile(attitude):
                sources.append({
                    'source_type': GIPSYXData.ATTITUDE_FILE,
                    'file': attitude
                })
            else:
                return 'Attitude file %s does not exist.' % attitude

            if getattr(self.args, 'generate_quaternions', None):
                return 'Must specify either --generate-quaternions OR give an attitude file.'

        pressure = getattr(self.args, 'pressure', None)
        if pressure:
            if os.path.isfile(pressure):
                sources.append({
                    'source_type': GIPSYXData.PRESSURE_FILE,
                    'file': pressure
                })
            else:
                return 'Pressure file %s does not exist.' % attitude

        rinex = getattr(self.args, 'rinex', None)
        if rinex:
            if os.path.isfile(rinex):
                sources.append({
                    'source_type': GIPSYXData.RINEX_FILE,
                    'file': rinex
                })
            else:
                return 'RINEX file %s does not exist.' % attitude

        num_deleted = 0
        deletes = getattr(self.args, 'todelete', [])
        if deletes:
            for delete_lst in deletes:
                for todelete in delete_lst:
                    try:
                        src_typ = GIPSYXData.normalize_source_type(todelete)
                        sources.append({'source_type': src_typ, 'delete': True})
                        num_deleted += 1
                    except KeyError:
                        return 'Invalid source type: %s' % todelete

        unlabeled = getattr(self.args, 'source', [])
        if unlabeled:
            for srcs in unlabeled:
                for src in srcs:
                    if os.path.isfile(src):
                        sources.append({'file': src})
                    else:
                        return 'Unidentified source file %s does not exist.' % src

        for uuid in ids:

            if self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug('Fetching details for data: %s', uuid)

            details = self.apps.detail(uuid)
            updates = self.build_option_dict(self.OPTIONS, self.args)

            to_send = {}
            for key, value in updates.items():
                if key not in details or value != details[key]:
                    to_send[key] = value

            toupload = 0
            if sources:
                to_send['sources'] = sources
                toupload = len(sources) - num_deleted

            ret = {}
            if len(to_send) > 0 and toupload == 0:
                ret = self.apps.update_data(uuid, **to_send).json()
            elif toupload > 0:
                if self.args.no_progress or self.args.json:
                    ret = self.apps.update_data(
                        uuid,
                        **to_send,
                        stream=True
                    ).json()
                else:
                    from tqdm import tqdm
                    with tqdm(
                            total=sum([os.path.getsize(f['file']) for f in sources if f['file']]),
                            unit='B',
                            unit_scale=True,
                            unit_divisor=1024,
                            postfix={'data': uuid, 'name': self.apps.get_data_parameter(uuid, 'name')}
                    ) as progress_bar:
                        ret = self.apps.update_data(
                            uuid,
                            **to_send,
                            stream=True,
                            progress_hook=lambda bytes_read: progress_bar.update(bytes_read)
                        ).json()
            else:
                if self.args.json:
                    self.pretty_print_json(self.apps.cached_data().get(uuid, {}))
                else:
                    print('No updates to be made for [ %s | %s]' % (self.apps.cached_data()[uuid]['name'], uuid))

            if ret:
                if self.args.json:
                    self.pretty_print_json(ret)
                else:
                    update_log = {}
                    for key, value in to_send.items():
                        if key.lower() == 'sources':
                            update_log[key] = value
                        else:
                            update_log[key] = "%s -> %s" % (details[key], value)
                        print('Updated [ %s | %s ] : %s' % (
                            self.apps.cached_data()[uuid]['name'], uuid, pformat(update_log)
                        ))


def main():
    cmd = APPSUpdate()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
