from ..cmd import APPSCommand
from ..defines import *
from pprint import (
    pformat,
    pprint
)
import logging
import sys


def get_parser():
    return APPSProfile().parser


class APPSProfile(APPSCommand):
    DESCRIPTION = 'View or change your user profile on the GDGPS Automatic Precise Point Positioning Service.'
    OPTIONS = 'profile'

    logger = logging.getLogger(__name__ + '.APPSProfile')

    def __init__(self):
        super(APPSProfile, self).__init__()

        self.parser.add_argument(
            '--timezone-options',
            action='store_true',
            dest='timezone_options',
            default=False,
            help='List the valid timezone option strings.'
        )

    def _main(self):

        if self.args.timezone_options:
            pprint([tz[0] for tz in UserProfile.TIMEZONES])
        else:
            to_change = self.build_option_dict(self.OPTIONS, self.args)
            if len(to_change) > 0 and self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug('Updating user profile settings to %s.' % (pformat(to_change),))

            if len(to_change) > 0:
                self.apps.update_profile(**to_change)
            self.pretty_print_json(self.apps.profile())

        self.apps.update_credential()


def main():
    cmd = APPSProfile()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
