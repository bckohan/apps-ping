from ..cmd import APPSCommand
from ..exceptions import DataNotFound
from ..defines import GIPSYXData
import logging
import sys
import os


def get_parser():
    return APPSUpdate().parser


class APPSUpdate(APPSCommand):
    DESCRIPTION = 'Add or delete or list source files to a GIPSYXData submission. The submission must be in a valid ' \
                  'state'

    logger = logging.getLogger(__name__ + '.APPSUpdate')

    UPLOAD_VALID_STATES = GIPSYXData.SOURCE_CHANGE_STATES
    DELETE_VALID_STATES = GIPSYXData.SOURCE_CHANGE_STATES + [
        GIPSYXData.DONE, GIPSYXData.AVAILABLE, GIPSYXData.RETRIEVED
    ]
    LIST_VALID_STATES = [s[0] for s in GIPSYXData.STATES]

    def __init__(self):

        super(APPSUpdate, self).__init__()

        # TODO move this to the subparsers
        sp = self.parser.add_subparsers(title='Action Types', dest='action')

        delete_parser = sp.add_parser(
            'delete',
            description='Delete the specified source or sources matching the given selectors.'
        )
        delete_parser.add_argument(
            'selector',
            metavar='D',
            nargs='?',
            help='The selectors matching the data items whose sources you would like to delete. ' +
                 self.DATA_SELECTOR_HELP % (
                     [GIPSYXData.get_verbose_state(state) for state in self.DELETE_VALID_STATES],
                 )
        )

        grp = delete_parser.add_mutually_exclusive_group()
        grp.add_argument(
            '-t',
            '--type',
            type=str,
            dest='source_type',
            choices=[s for s, l in GIPSYXData.SOURCE_TYPES],
            help='The type of the source file(s) to delete. Must be one of: ' + ','.join(
                ['%s: %s' % (s, l) for s, l in GIPSYXData.SOURCE_TYPES]
            ),
            default=None
        )

        grp.add_argument(
            '-n',
            '--name',
            type=str,
            dest='name',
            help='The name of the source(s) to delete.',
            default=None
        )

        upload_parser = sp.add_parser(
            'upload',
            description='Upload new sources to the specified data submission.'
        )
        upload_parser.add_argument(
            'selector',
            metavar='D',
            nargs='?',
            help='The selectors matching the data items you would like to supply additional source data for. ' +
                 self.DATA_SELECTOR_HELP % (
                     [GIPSYXData.get_verbose_state(state) for state in self.UPLOAD_VALID_STATES],
                 )
        )

        upload_parser.add_argument(
            'file',
            metavar='F',
            nargs=1,
            help='The path of the source file to upload.'
        )

        upload_parser.add_argument(
            '-t',
            '--type',
            type=str,
            dest='source_type',
            choices=[s for s, l in GIPSYXData.SOURCE_TYPES if s != GIPSYXData.RINEX_FILE],
            help='The type of the source file to upload. Must be one of: ' + ','.join(
                ['%s: %s' % (s, l) for s, l in GIPSYXData.SOURCE_TYPES if s != GIPSYXData.RINEX_FILE]
            ),
            default=None
        )

        upload_parser.add_argument(
            '--no-progress',
            action='store_true',
            dest='no_progress',
            help='Turn off the upload progress indicator.',
            default=False
        )

        list_parser = sp.add_parser(
            'list',
            description='List sources associated with the selected data and/or of the specified type and name.'
        )
        list_parser.add_argument(
            'selector',
            metavar='D',
            nargs='?',
            help='The selectors matching the data items you would like to list source information for. ' +
                 self.DATA_SELECTOR_HELP % ([ GIPSYXData.get_verbose_state(state) for state in self.LIST_VALID_STATES],)
        )

        grp = list_parser.add_mutually_exclusive_group()
        grp.add_argument(
            '-t',
            '--type',
            type=str,
            dest='source_type',
            choices=[s for s, l in GIPSYXData.SOURCE_TYPES],
            help='The type of the source file(s) to list. Must be one of: ' + ','.join(
                ['%s: %s' % (s, l) for s, l in GIPSYXData.SOURCE_TYPES]
            ),
            default=None
        )

        grp.add_argument(
            '-n',
            '--name',
            type=str,
            dest='name',
            help='The name of the source(s) to list.',
            default=None
        )

    def _main(self):

        self.apps.list_data()

        ids = []
        ids_are_sources = False
        if self.args.selector:
            try:
                ids = self.resolve_selectors(
                    self.args.selector
                )
            except DataNotFound:
                if self.apps.is_id(self.args.selector):
                    ids.append(self.args.selector)
                    ids_are_sources = True

        if self.args.action == 'list':
            sources = []
            source_type = getattr(self.args, 'source_type', None)
            if source_type:
                source_type = GIPSYXData.normalize_source_type(source_type)
            name = getattr(self.args, 'name', None)

            def filter_src(srcobj):
                if source_type:
                    if srcobj['source_type'] == source_type:
                        return True
                elif name:
                    if name.lower() == srcobj['name'].lower():
                        return True
                else:
                    return True
                return False

            if ids:
                if ids_are_sources:
                    for sid in ids:
                        src = self.apps.get_source(sid=sid)
                        if src and filter_src(src):
                            sources.append(src)
                else:
                    for dataid in ids:
                        for src in self.apps.get_data_parameter(dataid, 'source_types'):
                            if filter_src(src):
                                src['data'] = dataid
                                sources.append(src)
            else:
                for src in self.apps.sources():
                    if filter_src(src):
                        sources.append(src)

            if self.args.json:
                self.pretty_print_json(sources)
            else:
                for src in sources:
                    print(self.src_to_str(src))

        elif self.args.action == 'delete':
            if not ids:
                return "No data or source matched selector for deletion."
            deleted = []
            for idx in ids:
                if ids_are_sources:
                    deleted.extend(self.apps.delete_source(idx))
                    if not self.args.json:
                        print('Deleted source: %s' % self.src_to_str(deleted[-1]))
                else:
                    ftr = getattr(self.args, 'name', None)
                    if not ftr:
                        ftr = getattr(self.args, 'source_type', None)
                    new_deletes = self.apps.delete_source((idx, ftr))
                    if not self.args.json:
                        for nd in new_deletes:
                            print('Deleted source %s' % self.src_to_str(nd))
                    deleted.extend(new_deletes)
                if self.args.json:
                    self.pretty_print_json(deleted)

        elif self.args.action == 'upload':
            if ids_are_sources or not ids:
                return 'No data matched selection for source upload.'

            srcfile = os.path.normpath(self.args.file[0])
            if not os.path.isfile(srcfile):
                return '%s is not a file.' % (srcfile, )

            all_ret = []
            for idx in ids:
                self.logger.debug('Uploading %s to data %s...' % (srcfile, idx))
                if self.args.no_progress or self.args.json:
                    ret = self.apps.upload_source(
                        idx,
                        srcfile,
                        source_type=getattr(self.args, 'source_type', None),
                        stream=True
                    ).json()
                    if not self.args.json:
                        print('Uploaded: %s, size=%s, id=%s' % (srcfile, self.format_size(srcfile), ret['id']))
                else:
                    from tqdm import tqdm
                    postfix = {'file': os.path.basename(srcfile)}
                    with tqdm(
                            total=os.path.getsize(srcfile),
                            unit='B',
                            unit_scale=True,
                            unit_divisor=1024,
                            postfix=postfix
                    ) as progress_bar:
                        ret = self.apps.upload_source(
                            idx,
                            srcfile,
                            source_type=getattr(self.args, 'source_type', None),
                            stream=True,
                            progress_hook=lambda bytes_read: progress_bar.update(bytes_read)
                        ).json()
                        if 'name' in ret:
                            postfix['name'] = ret['name']
                        if 'id' in ret:
                            postfix['id'] = ret['id']
                        progress_bar.set_postfix(postfix)
                all_ret.append(ret)

                if self.args.json:
                    self.pretty_print_json(all_ret)

    @staticmethod
    def src_to_str(src):
        return 'data: %s, id %s, type: %s, name: %s' % (
            src['data'], src['id'], src['source_type'], src['name']
        )


def main():
    cmd = APPSUpdate()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
