from ..cmd import APPSCommand
from ..defines import *
import logging
import sys


def convert_lvl(l):
    try:
        return UserAlert.get_verbose_level(l).lower()
    except (AttributeError, KeyError):
        return l


def get_parser():
    return APPSAlerts().parser


class APPSAlerts(APPSCommand):
    DESCRIPTION = 'List any alerts for you on the GDGPS Automatic Precise Point Positioning Service.'

    logger = logging.getLogger(__name__ + '.APPSAlerts')

    def __init__(self):
        super(APPSAlerts, self).__init__()

        self.parser.add_argument(
            'levels',
            metavar='L',
            type=convert_lvl,
            nargs='*',
            choices=[lvl[1].lower() for lvl in UserAlert.LEVELS] + [[], ],
            help='The levels of alerts to fetch, if none are provided all alerts will be fetched.',
        )

    def _main(self):

        levels = self.args.levels
        alrts = self.apps.alerts()
        if len(alrts) == 0:
            print('There are no alerts.')
        else:
            if len(levels) > 0:
                self.pretty_print_json([alrt for alrt in alrts if alrt['level'] in levels])
            else:
                self.pretty_print_json(alrts)


def main():
    cmd = APPSAlerts()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
