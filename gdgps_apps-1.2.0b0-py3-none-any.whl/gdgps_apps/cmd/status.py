from ..cmd import APPSCommand
import logging
import sys
import json


def get_parser():
    return APPSStatus().parser


class APPSStatus(APPSCommand):
    DESCRIPTION = 'Print out a status report of the GDGPS Automatic Precise Point Positioning Service and your account.'

    logger = logging.getLogger(__name__ + '.APPSStatus')

    def __init__(self):
        super(APPSStatus, self).__init__()

    def _main(self):
        profile = self.apps.profile()
        alerts = self.apps.alerts()
        self.pretty_print_json(self.apps.list_processors())
        #TODO

def main():
    cmd = APPSStatus()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
