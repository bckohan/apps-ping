from ..cmd import APPSCommand
from ..defines import *
import logging
import sys


def get_parser():
    return APPSErrors().parser


class APPSErrors(APPSCommand):
    DESCRIPTION = 'List submissions on the GDGPS Automatic Precise Point Positioning Service that have errors and any '\
                  'information available about those errors.'

    logger = logging.getLogger(__name__ + '.APPSList')

    VALID_STATES = [Data.ERROR]

    def __init__(self):

        super(APPSErrors, self).__init__()

        self.parser.add_argument(
            'selectors',
            metavar='D',
            nargs='*',
            help='The list of data to get the errors of. If no identifiers are given list all submissions '
                 'with errors. ' + self.DATA_SELECTOR_HELP % (
                [Data.get_verbose_state(state) for state in self.VALID_STATES],
            ),
        )

    def _main(self):

        self.apps.list_data()

        ids = None
        if len(self.args.selectors) > 0:
            ids = self.resolve_selectors(self.args.selectors, valid_states=self.VALID_STATES)

        no_errors = True
        if ids is None:
            for uuid, info in self.apps.cached_data().items():
                if info['state'] == Data.ERROR:
                    printed = False
                    no_errors = False
                    for flag in info['flags']:
                        if flag['level'] == DataFlag.ERROR:
                            printed = True
                            print(self.format_data_error(info, flag))
                    if not printed:
                        print(self.format_data_error(info))
        else:
            for uuid in ids:
                data = self.apps.cached_data()[uuid]
                if data['state'] == Data.ERROR:
                    printed = False
                    no_errors = False
                    for flag in data['flags']:
                        if flag['level'] == DataFlag.ERROR:
                            printed = True
                            print(self.format_data_error(data, flag))
                    if not printed:
                        print(self.format_data_error(data))

        if no_errors:
            print('There are no submissions in the %s state.' % (Data.get_verbose_state(Data.ERROR, )))

    @staticmethod
    def format_data_error(data, flag=None):
        if flag is None:
            return '[ %s | %s ]' % (data['name'], data['id'])
        return '[ %s | %s ] : %s : %s' % (data['name'], data['id'], flag['header'], flag['detail'])


def main():
    cmd = APPSErrors()
    return cmd.main()


if __name__ == '__main__':
    sys.exit(main())
