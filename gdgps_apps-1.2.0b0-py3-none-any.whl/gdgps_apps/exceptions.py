class InvalidConfiguration(Exception):

    def __init__(self, *args):
        super(InvalidConfiguration, self).__init__(*args)


class InvalidAuthenticationCredentials(InvalidConfiguration):
    pass


class NoAvailableProcessors(Exception):

    def __init__(self, *args):
        super(NoAvailableProcessors, self).__init__(*args)


class UnableToReachHost(Exception):
    host = None

    def __init__(self, *args, host):
        self.host = host
        super(UnableToReachHost, self).__init__(*args)


class InvalidSelector(Exception):
    selector = None

    def __init__(self, *args, selector):
        self.selector = selector
        super(InvalidSelector, self).__init__(*args)


class InvalidIdentifier(Exception):
    uuid = None

    def __init__(self, *args, uuid):
        self.uuid = uuid
        super(InvalidIdentifier, self).__init__(*args)


class InvalidDataState(Exception):
    state = None

    def __init__(self, *args, state):
        self.state = state
        super(InvalidDataState, self).__init__(*args)


class ArtifactNotFound(Exception):
    uuid = None

    def __init__(self, *args, uuid):
        self.uuid = uuid
        super(ArtifactNotFound, self).__init__(*args)


class DataNotFound(ArtifactNotFound):
    """Thrown when a given data identifier is valid, but was not found in the system."""


class AlertNotFound(ArtifactNotFound):
    """Thrown when a given alert identifier is valid, but was not found in the system."""


class FlagNotFound(ArtifactNotFound):
    """Thrown when a given flag identifier is valid, but was not found in the system."""


class InvalidOperation(Exception):
    uuid = None

    def __init__(self, *args, uuid):
        self.uuid = uuid
        super(InvalidOperation, self).__init__(*args)


class UnauthorizedOperation(Exception):
    """The attempted operation is unauthorized based on the provided authentication parameters"""

    def __init__(self, *args):
        super(UnauthorizedOperation, self).__init__(*args)
