from .defines import *
from .apps import APPS
from .exceptions import (
    DataNotFound,
    AlertNotFound,
    ArtifactNotFound,
    InvalidOperation,
    NoAvailableProcessors,
    InvalidAuthenticationCredentials,
    InvalidConfiguration,
    InvalidSelector,
    InvalidIdentifier,
    InvalidDataState,
    UnableToReachHost,
    UnauthorizedOperation
)
from requests.exceptions import HTTPError
import cmd
import argparse
import os
import sys
import json
import glob
import re
from pprint import (
    pprint,
    pformat
)
from copy import copy
import traceback
from tqdm import tqdm
import errno

'''
A bit of code to get tab completion to hopefully work on OSX platforms

https://stackoverflow.com/questions/7116038/python-tab-completion-mac-osx-10-7-lion
'''
try:
    import readline
    import rlcompleter

    if 'libedit' in readline.__doc__:
        readline.parse_and_bind('bind ^I rl_complete')
    else:
        readline.parse_and_bind('tab: complete')
except Exception:
    pass


class APPSCmdLine(cmd.Cmd):
    intro = 'Welcome to the GDGPS APPS Command Line shell. Type help or ? to list commands.\n'
    prompt = 'apps> '
    apps = None
    last_output = ''
    chunk_size = 1  # 64 * 1024 #64kB

    def get_options(self, options):
        print(
            'Enter \'help\' to get an explanation of any parameter. Enter \'exit\' to quit the shell or \'cancel\' to'
            ' cancel this operation.'
        )
        selections = {}
        for option, params in options.items():
            selection = self.get_option(option, params)
            if selection is not None and not (isinstance(selection, str) and len(selection) == 0):
                selections[option] = selection
            if selection == 'exit' or selection == 'quit' or selection == 'cancel':
                return selection
        return selections

    def get_option(self, option, params):
        required = params.get('required', False) and 'default' not in params
        prmpt_str = option
        choice_tpl = None
        if 'choices' in params:
            choice_tpl = tuple([choice[0] for choice in params['choices']])
            prmpt_str += ' %s' % (choice_tpl,)
        if 'default' in params:
            prmpt_str += ' [ %s ]' % (params['default'],)
        val = input(prmpt_str + '? ').strip().lower()
        if len(val) == 0:
            if required:
                return self.get_option(option, params)
            return None
        if val == 'help':
            hlp = params.get('help', None)
            if not hlp:
                hlp = 'No help information is available for this parameter. Please see the website for documentation.'
            print('\n%s\n' % (hlp,))
            return self.get_option(option, params)
        if val == 'exit' or val == 'quit' or val == 'cancel':
            return val
        if type(val) != params['type']:
            try:
                if params['type'] == bool:
                    if val in ['n', 'no', '0', 'false']:
                        val = False
                    elif val in ['y', 'yes', '1', 'true']:
                        val = True
                    else:
                        raise ValueError('Unrecognized input for boolean: %s' % (val,))
                else:
                    val = params['type'](val)
            except Exception as e:
                print('%s given incorrect input: %s' % (option, e))
                return self.get_option(option, params)

        if choice_tpl and val not in choice_tpl:
            print('Invalid input, must be one of %s.' % (choice_tpl,))
            self.get_option(option, params)

        return val

    def __init__(self, **kwargs):
        super(APPSCmdLine, self).__init__()
        self.apps = APPS(**kwargs)

    def cmdloop(self, intro=None):
        try:
            super(APPSCmdLine, self).cmdloop(intro=intro)
        except DataNotFound as e:
            print('Data %s was not found in the system!' % e.uuid)
            self.cmdloop(intro='')
        except AlertNotFound as e:
            print('Alert %s was not found in the system!' % e.uuid)
            self.cmdloop(intro='')
        except ArtifactNotFound as e:
            print(str(e))
            self.cmdloop(intro='')
        except UnauthorizedOperation as e:
            print('Operation %s, is unauthorized: %s' % (self.lastcmd, str(e)))
            self.cmdloop(intro='')
        except InvalidOperation as e:
            print('Operation %s is invalid%s' % (self.lastcmd, '!' if len(str(e)) == 0 else ': ' + str(e)))
            self.cmdloop(intro='')
        except NoAvailableProcessors as e:
            print('Unable to complete operation %s because: %s' % (self.lastcmd, str(e)))
            self.cmdloop(intro='')
        except UnableToReachHost as e:
            print(
                'Unable to reach the host %s, please try again later%s' % (
                    e.host, ': ' + str(e) if len(str(e)) > 0 else '.'
                )
            )
            self.cmdloop(intro='')
        except InvalidSelector as e:
            print(str(e))
            self.cmdloop(intro='')
        except InvalidIdentifier as e:
            print(str(e))
            self.cmdloop(intro='')
        except InvalidDataState as e:
            print(str(e))
            self.cmdloop(intro='')
        except HTTPError as e:
            try:
                ctn = e.response.content.decode('UTF-8')
                try:
                    ctn = pformat(json.loads(e.response.content))
                except Exception:
                    print(str(e))
                print('%s:\n%s' % (e.args[0], ctn))
            except Exception:
                print(str(e))
            self.cmdloop(intro='')
        except Exception:
            tb = traceback.format_exc()
            print('Unexpected exception encountered, if this condition persists contact the administrators: %s' % (tb,))
            self.cmdloop(intro='')
            # return

    def complete_upload(self, text, line, begidx, endidx):
        return self.path_matches(text)

    @staticmethod
    def path_matches(path_prefix):
        if len(path_prefix) == 0:
            path_prefix = './*'
        else:
            path_prefix.replace('\\', '/')
            path_prefix = os.path.normpath(path_prefix)
            if os.path.isdir(path_prefix):
                path_prefix += '/*'
            else:
                path_prefix += '*'
        return [os.path.normpath(m).replace('\\', '/') for m in glob.glob(path_prefix) if m != './' and m != '.\\']

    def data_id_matches(self, id_prefix, state_filter=None):
        id_prefix = id_prefix.lower()
        if len(id_prefix) == 0:
            return list(self.apps.cached_data().keys())
        if state_filter:
            return [uuid for uuid, val in list(self.apps.cached_data().items()) if
                    uuid.startswith(id_prefix) and val['state'] in state_filter]
        return [uuid for uuid in list(self.apps.cached_data().keys()) if uuid.startswith(id_prefix)]

    def data_name_matches(self, name_prefix, state_filter=None, offset=0):
        name_prefix = name_prefix.lower()
        if state_filter:
            return [val['name'][offset:] for val in list(self.apps.cached_data().values()) if
                    val['name'].startswith(name_prefix) and val['state'] in state_filter]
        return [val['name'][offset:] for val in list(self.apps.cached_data().values()) if
                val['name'].startswith(name_prefix)]

    @staticmethod
    def data_state_matches(state_prefix, state_filter=None):
        states = []
        for state in Data.STATES:
            if not state_filter or state[0] in state_filter:
                states.append(state[1].lower())
        if len(state_prefix) == 0:
            return states
        return [s for s in states if s.startswith(state_prefix.lower())]

    def data_select_match(self, prefix, state_filter=None, special_selectors=None):
        selections = self.data_name_matches(prefix, state_filter)
        selections.extend(self.data_state_matches(prefix, state_filter))
        if special_selectors:
            selections.extend([s for s in special_selectors if s.startswith(prefix.lower())])
        return selections

    def do_shell(self, line):
        """Run a shell command"""
        output = os.popen(line).read()
        print(output)
        self.last_output = output

    def do_delete(self, arg):
        """Delete the given data by ID or all data in the given state, or all data: delete [ID|state|all]"""
        ids = self.__selector_to_ids__(arg, special_selectors={'all': lambda: [d['id'] for d in self.apps.list_data()]})
        if len(ids) == 0:
            print('Must provide a target for deletion, either by identifier, state or all data.')
        else:
            for uuid in ids:
                if self.apps.delete_data(uuid):
                    print('Deleted data %s' % uuid)

    def complete_delete(self, text, line, begidx, endidx):
        return self.data_select_match(text, special_selectors=['all'])

    def do_echo(self, line):
        """Print the input, replacing '$out' with the output of the last shell command"""
        print(line.replace('$out', self.last_output))

    def do_EOF(self, line):
        """Send EOF to exit (CTRL-Z)"""
        return True

    def do_update_profile(self, arg):
        """Update your user profile."""
        current = self.apps.profile()
        opts = copy(self.apps.OPTIONS['profile'])
        for key in opts.keys():
            if key in current:
                opts[key]['default'] = current[key]

        options = self.get_options(opts)
        if isinstance(options, str):
            if options == 'exit' or options == 'quit':
                return True
            elif options == 'cancel':
                return

        if self.apps.update_profile(**options):
            pprint(self.apps.profile())

    def do_profile(self, arg):
        """List your profile settings."""
        pprint(self.apps.profile())

    def do_alerts(self, arg):
        """List all system and user level alerts."""
        alrts = self.apps.alerts()
        if len(alrts) == 0:
            print('There are no alerts.')
        else:
            pprint(alrts)

    def do_load(self, arg):
        """Load a settings file from a given path: load ./apps_settings"""
        arg = arg.strip()
        if len(arg) == 0:
            print('You must supply a settings file path!')
        elif not os.path.exists(arg) or not os.path.isfile(arg):
            print('Settings file %s, does not exist!' % (arg,))
        else:
            try:
                if self.apps is not None:
                    download_dir = self.apps.download_directory_
                    apps = APPS(settings_file=arg, download_directory=download_dir)
                    self.apps = apps
                else:
                    apps = APPS(settings_file=arg)
                    self.apps = apps
            except InvalidAuthenticationCredentials as e:
                print('Authentication credentials supplied in settings file %s are invalid: %s' % (arg, str(e)))
            except InvalidConfiguration as e:
                print('Configuration parameters supplied in settings file %s are invalid: %s' % (arg, str(e)))

    def do_approve(self, arg):
        """Approve the given data for processing, or prompt for all elligible data if no identifier is
        specified: approve [name]"""
        toauth = self.__selector_to_ids__(
            arg,
            special_selectors={
                'all':
                    lambda: [d['id'] for d in self.apps.list_data() if d['state'] == Data.VERIFIED]
            }
        )

        if len(toauth) == 0:
            nodata = True
            if len(arg.strip()) == 0:
                for data in [d for d in self.apps.list_data() if d['state'] == 'V']:
                    nodata = False
                    doauth = input('Approve %s, y/n? (y): ' % (data['name'])).lower()
                    if doauth in ['', 'y', 'yes']:
                        if self.apps.approve(data['id']):
                            print(data['name'] + ' has been approved for processing!')
            if nodata:
                print('No data needs authorization.')
        else:
            for uuid in toauth:
                if self.apps.approve(uuid):
                    print(uuid + ' has been approved for processing!')

    def complete_approve(self, text, line, begidx, endidx):
        return self.data_select_match(
            text,
            state_filter=[Data.VERIFIED],
            special_selectors=['all']
        )

    def do_list(self, arg):
        """List all data items, or optionally, all data items in the given state: list [state]."""
        state = arg.strip()
        if len(state) > 0:
            state = Data.normalize_state(state)
        data = [{
            'id': d['id'],
            'name': d['name'],
            'time': d['time'],
            'state': Data.get_verbose_state(d['state']),
        } for d in self.apps.list_data() if (len(state) == 0 or d['state'] == state)]
        pprint(data)

    def do_upload(self, arg):
        """Upload a given RINEX file to APPS for processing: upload path/to/file1 path/to/file2
        The file path can be a unix shell style matching pattern. You will be prompted for processing options. The same
        options will be applied to every file if there is more than one."""

        glbs = arg.split(' ')  # TODO account for paths with spaces... use \ as escape character?

        paths = []
        for glb in glbs:
            paths.extend(glob.glob(glb))

        if len(paths) == 0:
            print(glb + ' did not match any files.')

        options = self.get_options(self.apps.OPTIONS['gipsyxdata'])
        if isinstance(options, str):
            if options == 'exit' or options == 'quit':
                return True
            elif options == 'cancel':
                return

        for path in paths:
            with tqdm(
                    total=os.path.getsize(path),
                    unit='B',
                    unit_scale=True,
                    unit_divisor=1024,
                    postfix={'file': path}
            ) as progress_bar:
                self.apps.upload_gipsyx(
                    path,
                    stream=True,
                    progress_hook=lambda bytes_read: progress_bar.update(bytes_read),
                    **options
                )

    def do_processors(self, arg):
        """List all the processors available for data upload."""
        pprint(self.apps.list_processors())

    def do_download_src(self, arg):
        """Download the source files for submissions in the given state or specified
        identifier: download_src [ID|state|all]"""
        pass

    def do_download(self, arg):
        """Download positioning results for submissions in the given state or specified identifier. By default, all
        available but unretrieved results will be downloaded: download [ID|state|all]"""
        selector = arg.strip()
        dr = self.apps.download_directory
        if os.path.exists(dr) and not os.path.isdir(dr):
            print('Will not overwrite %s, please specify a different download path.' % dr)
            return False
        elif not os.path.exists(dr):
            try:
                os.makedirs(dr)
            except OSError as e:
                if e.errno != errno.EEXIST:
                    print('Error, cannot create download directory %s: %s' % (dr, str(e)))
                    return False

        if len(selector) == 0:
            to_download = [d['id'] for d in self.apps.list_data() if d['state'] == Data.AVAILABLE]
            if len(to_download) > 0:
                print('Downloading all available, previously unretrieved data.')
            else:
                print('No data is available for download that has not been previously retrieved.')
        else:
            to_download = self.__selector_to_ids__(
                selector,
                special_selectors={
                    'all':
                        lambda: [
                            d['id'] for d in self.apps.list_data() if d['state'] in (Data.AVAILABLE, Data.RETRIEVED)
                        ]
                }
            )
            if len(to_download) == 0:
                print('No data matching selector %s is available for download.' % (selector,))

        for uuid in to_download:
            try:
                size = None if 'res_size_on_disk' not in self.apps.cached_data()[uuid] else int(
                    self.apps.cached_data()[uuid]['res_size_on_disk'])
                resp = self.apps.download_result(
                    uuid=uuid,
                    stream=True,
                    write_to_disk=False
                )
                if resp and resp.ok:
                    if 'content-length' in resp.headers:
                        size = int(resp.headers['content-length'])

                    filename = self.apps.cached_data()[uuid]['name']
                    if 'content-disposition' in resp.headers:
                        filename = re.findall("filename=(.+)", resp.headers['content-disposition'])

                    dl_path = os.path.normpath(dr + '/' + filename[0].replace('"', ''))
                    chunk_size = 32 * 1024
                    with open(dl_path, 'wb') as dout:
                        with tqdm(
                                total=size,
                                unit='B',
                                unit_scale=True,
                                unit_divisor=1024,
                                postfix={'file': dl_path}
                        ) as progress_bar:
                            while True:
                                chunk = resp.raw.read(chunk_size)
                                if not chunk:
                                    progress_bar.update()
                                    break
                                progress_bar.update(dout.write(chunk))
                else:
                    state = self.apps.detail(uuid)['state']
                    reason = ''
                    if state != Data.AVAILABLE and state != Data.RETRIEVED:
                        reason = 'The file is not yet available for download.'
                    elif resp:
                        reason = '%s%s' % (str(resp.status_code) + ' ' + resp.reason,
                                           ' [ ' + resp.text + ' ]' if len(resp.text) > 0 else '')

                    print('Unable to download %s: %s' % (uuid, reason))

            except Exception as e:
                print('Unable to download %s: %s' % (uuid, str(e)))

    def complete_download(self, text, line, begidx, endidx):
        ret = self.data_select_match(
            text,
            state_filter=[Data.AVAILABLE, Data.RETRIEVED],
            special_selectors=['all']
        )
        return ret

    def do_detail(self, arg):
        """List all details for the given data item, listed by unique dataid: detail ID"""
        for uuid in self.__selector_to_ids__(arg):
            pprint(self.apps.detail(uuid))

    def complete_detail(self, text, line, begidx, endidx):
        return self.data_name_matches(text)

    def do_download_dir(self, arg):
        """Display or update the directory where downloaded files will be saved."""
        newdir = arg.strip()
        if len(newdir) > 0:
            if os.path.isdir(newdir):
                self.apps.download_directory = newdir
            else:
                print('%s does not exist.' % newdir)
                return
        print(self.apps.download_directory)

    def do_errors(self, arg):
        """List data items in the error state, and any error flags associated with them."""
        errors = [{
            'id': d['id'],
            'name': d['name'],
            'time': d['time'],
            'state': Data.get_verbose_state(d['state']),
            'errors': [{e['header']: e['detail']} for e in d['flags'] if e['level'] == DataFlag.ERROR]
        } for d in self.apps.list_data() if d['state'] == Data.ERROR]
        if len(errors) == 0:
            print('There are no errors.')
        else:
            pprint(errors)

    def do_exit(self, arg):
        """Quit the GDGPS APPS Command Line shell."""
        return True

    def do_quit(self, arg):
        """Quit the GDGPS APPS Command Line Shell."""
        return True

    def __names__(self):
        return [val['name'] for val in list(self.apps.cached_data().values())]

    def __selector_to_ids__(self, selector, special_selectors=None):
        if special_selectors is None:
            special_selectors = {}
        selector = selector.strip()
        if self.apps.is_id(selector):
            return [selector]
        uuid = self.apps.id_for_name(selector)
        if uuid is not None:
            return [uuid]
        ids = []
        try:
            return self.apps.data_in_states(selector)
        except KeyError:
            pass

        valid = not (len(selector) > 0 and len(ids) == 0)
        if len(ids) == 0:
            if selector in special_selectors:
                valid = True
                ids = special_selectors[selector]()

        if not valid:
            raise InvalidSelector('%s is not a valid data selector.' % selector, selector=selector)

        return ids


if __name__ == '__main__':

    parser = argparse.ArgumentParser(
        description='Run the GDGPS Automatic Precise Point Positioning Service command line interface.',
    )

    parser.add_argument(
        '-s',
        '--settings',
        type=str,
        default=os.path.expanduser('~') + '/.apps_settings',
        help='APPS configuration parameters, including access credentials.',
        required=False
    )

    parser.add_argument(
        '-d',
        '--download-dir',
        type=str,
        default=os.getcwd(),
        help='The destination directory for downloaded files.',
        required=False
    )

    parser.add_argument(
        '-t',
        '--trust-env',
        action='store_true',
        help='Trust environment networking settings such as proxies (see requests library). If a netrc is present it '
             'will likely cause APPS to break so only enable this if you really need to.'
    )

    args = parser.parse_args()

    if not os.path.exists(args.settings):
        sys.exit('Error, settings file: %s does not exist!' % (args.settings,))

    APPSCmdLine(
        settings_file=args.settings,
        download_directory=args.download_dir,
        trust_env=args.trust_env
    ).cmdloop()
